Modified by Ravignir based on Civ5 Expansion mod by Red11.
Most of the art by Red11, LynxRo, GeneralWadaling, Ravignir, Firelord.
Contains stuff from mods:
- Uciv WWII by Subcher
- More Luxuries by Kolobok
- More Buildings by Shannaurelle
- Extra Resources by Cavenir
- LEKmod for Civ5 by lek
- FantasyHex Black Arquebusier art done by Sacafan
- [Feather](https://thenounproject.com/term/feather/1628/) By Eduardo Souza for Constitution
- Violin by SHAHAREA from [Noun Project](https://thenounproject.com/browse/icons/term/violin/) (CC BY 3.0)
- [Revolution Fist](https://thenounproject.com/icon/revolution-fist-398854/) by Jarem Frye for Cultural Revolution
- [Explore](https://thenounproject.com/icon/explore-6697620/) by Creative Iconix for Exploration
- [spy](https://thenounproject.com/icon/spy-5040795/) by Zeeshan Afzal for Double Agents
- [Army Helmet](https://thenounproject.com/icon/army-helmet-5803647/) by 4ubrand for People's Army
- [Pilot](https://thenounproject.com/icon/pilot-6304259/) by sulis setiyo for Arsenal of Democracy
- [Baby](https://thenounproject.com/icon/baby-6996109/) by Humam for Resettlements
- [Space Ship](https://thenounproject.com/icon/space-ship-357760/) by Ralf Schmitzer for Spaceflight Pioneers
- [Incognito](https://thenounproject.com/icon/incognito-43596/) by Alen Krummenacher for Covert Action
- [Art](https://thenounproject.com/icon/art-7296246/) by indah rusiati for Creative Expression
- [Money](https://thenounproject.com/icon/money-7316401/) by icon 5 for Economic Union
- [Mind](https://thenounproject.com/icon/mind-4602116/) by Ilham Fitrotul Hayat for Free Mind
- [Start Up](https://thenounproject.com/icon/start-up-5993269/) by my for Space Procurements
- [Specialist](https://thenounproject.com/icon/specialist-2762906/) by visual language for Treaty Organization
- [all seeing eye](https://thenounproject.com/icon/all-seeing-eye-96280/) by Kyle Tezak for Cult of Personality
- [Future](https://thenounproject.com/icon/future-6004550/) by iconmas for Futurism
- [Knife](https://thenounproject.com/icon/knife-302762/) by parkjisun for Gunboat Diplomacy
- [Preview Pane](https://thenounproject.com/icon/preview-pane-5625396/) by M. Oki Orlando for Industrial Espionage
- [Fist](https://thenounproject.com/icon/fist-7312433/) by Annisa for Iron Fist
- [Lightning](https://thenounproject.com/icon/lightning-5178353/) by MihiMihi for Lightning Warfare
- [Idea](https://thenounproject.com/icon/idea-7336528/) by NAPISAH for Ideology
- [Teamwork](https://www.freepik.com/icon/teamwork_6321379#fromView=search&page=1&position=30&uuid=ae02d268-a17d-4a63-bd6b-724cba646173) by Aficons studio for Cultural Revolution
- [Tools](https://www.freepik.com/icon/construction-tools_10364500#fromView=search&page=1&position=0&uuid=d7e23f69-0cca-4044-8f4d-3e8b7a64a30e) by IconMarketPK for Worker Faculties

## Buildings

- [Poem](https://thenounproject.com/icon/poem-7114623/) by WR Graphic Garage for Great Writing Slots
- [Museum](https://thenounproject.com/icon/museum-7343753/) by Ali Nur Rohman for Art Hall
- [Tomb](https://thenounproject.com/icon/tomb-3984836/) by Icon Market for Ayyubid Burial Tomb
- [Castle](https://thenounproject.com/icon/castle-7264302/) by ahmadwil for Feitoria
- [Idea](https://thenounproject.com/icon/idea-7336528/) by NAPISAH for Center of Progress
- [Art](https://thenounproject.com/icon/art-7296246/) by indah rusiati for Fine Art Specialist
- [Ski](https://thenounproject.com/icon/ski-4704572/) by Flowicon for Ski Resort
- [Kosmaj](https://thenounproject.com/icon/kosmaj-4484884/) by Marin for Spomenik
- [Donkey](https://thenounproject.com/icon/donkey-7259233/) by Iconiyo for Yam Route
- [Artist](https://thenounproject.com/icon/artist-7290494/) by Serena for Artist Guild
- [Borobudur](https://thenounproject.com/icon/borobudur-5532295/) by Selot Lo
- [Marquee](https://thenounproject.com/icon/marquee-1546225/) by JS Beaulieu for Broadway
- [Temple](https://thenounproject.com/icon/temple-7321361/) by Fauzi Arts for King Soloman's Temple
- [Mansion](https://thenounproject.com/icon/mansion-1961039/) by Smalllike for Governor's Mansion
- [Music Book](https://thenounproject.com/icon/music-book-5459277/) by Brickclay for Great Music Slots
- [History Book](https://thenounproject.com/icon/history-book-6890075/) by Designing Hub for Writing Auditorim
- [Drawing](https://www.freepik.com/icon/drawing_9014817#fromView=search&page=2&position=73&uuid=7026c7ed-a47e-4f25-b545-6840bce063f1) by kmg design for Great Art Slots
- [Oil Factory](https://thenounproject.com/icon/oil-factory-6694218/) by BinikSol for BMPC Plant
- [Globe Theatre](https://thenounproject.com/icon/globe-theatre-5286089/) by Lia Thompson for Globe Theatre
- [Hermitage](https://thenounproject.com/icon/russian-museum-4944136/) by Amethyst Studio for Hermitage GW slots
- [Blue mosque](https://www.freepik.com/icon/blue-mosque_763021) by Freepik for Vocal Chamber
- [Palace](https://www.freepik.com/icon/palace_5897551#fromView=search&page=1&position=7&uuid=d03c19a5-f888-474b-95ab-338464228e1f) by Kanyanee Watanajitkasem for Great Canal of Venice
- [Castle](https://thenounproject.com/icon/castle-7245381/) by Amir Ali for Castle Builders
- [Cathedral](https://www.freepik.com/icon/christ-church_5389472#fromView=search&page=2&position=12&uuid=7bf75c9e-4568-44af-be88-758293ee8b25) by Amethyst prime for Cathedral of Vilnius
- [Temple](https://www.freepik.com/icon/temple_5967676#fromView=search&page=7&position=6&uuid=62989b46-b1ed-4e91-8811-0a27cf5833e5) by Freepik for Huey Teocalli
- [Violin](https://www.freepik.com/icon/violin_1667732#fromView=search&page=1&position=23&uuid=d0b64c46-14d1-4da6-aef4-7400f2bb9d7d) by andinur for Musician Guild
- [Scroll](https://www.freepik.com/icon/scroll_2328602#fromView=search&page=2&position=5&uuid=31ce2c47-a2a0-43b7-89c6-ef301c99663b) by Eucalyp for Writing Guild
- [Igloo](https://www.freepik.com/icon/igloo_7658414#fromView=search&page=2&position=21&uuid=79b64564-ec97-4883-94a9-a867e1860917) by Freepik for Rocke-hewn church
- [Minar](https://www.freepik.com/icon/qutb-minar_3186670#fromView=search&page=1&position=20&uuid=b5a934d7-7209-4ba9-8158-43954e56a2a1) by surang for Minaa
- [Dock](https://thenounproject.com/icon/dock-4489742/) by Flowicon for Dry Dock
- [Factory](https://thenounproject.com/icon/factory-6833299/) by Hadi Mulyono for Cooperation
- [Barn](https://thenounproject.com/icon/barn-6373750/) by Amazona Adorada for Cacicazgo

## Resources

- [Factory](https://thenounproject.com/icon/factory-1559700/) by iconsphere for Factories
- [Policy](https://thenounproject.com/icon/policy-6460485/) by Dewanata Visuals for Policies
- [Coconut](https://thenounproject.com/icon/coconut-3418890/) by yandi kiem lie

## Units

- [Rifle](https://thenounproject.com/icon/rifle-4424066/) by ka reemov for Anti-Tank Rifle
- [War Ship](https://thenounproject.com/icon/war-ship-5307671/) by SHAHAREA for Heavy Cruiser
- [Tank](https://thenounproject.com/icon/tank-7284085/) by Taewon Kang for M-84
- [Halberd](https://thenounproject.com/icon/halberd-440848/) by Parkjisun for Reislaufer
- [Helicopter](https://thenounproject.com/icon/helicopter-6903169/) by swk for Cardoen
- [Beret](https://thenounproject.com/icon/beret-6945974/) by krisna arga muria for Expeditionary Force
- [hat](https://thenounproject.com/icon/hat-7388612/) by Haider Ali for Gerilya
- [Church](https://thenounproject.com/icon/church-1855092/) by Smashicons for National Church
- [Swimmer](https://thenounproject.com/icon/swimmer-6735717/) by yode tive for Fast Swimmer
- [Beret](https://thenounproject.com/icon/beret-6945974/) by krisna arga muria for Expeditionary Force
- [Horse](https://thenounproject.com/icon/horse-2191914/) by RIZCA for Llanero
