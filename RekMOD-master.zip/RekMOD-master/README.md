# RekMOD
Mod based on recreating Lekmod, a multiplayer mod for civ 5 
You can find many of the changes or attempted changes in this mod here:
https://docs.google.com/document/d/18tsjg2C1wKA7I41GktDRr6R83eUrhn4FHi9EUEtpKvI/edit?usp=sharing
